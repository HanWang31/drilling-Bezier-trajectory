# -*- coding: utf-8 -*-
"""
贝塞尔曲线轨迹优化设计
- 按段设计井眼轨迹，满足最大曲率约束
- 输出轨迹图像与 Excel 数据
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image
import matplotlib
from scipy.interpolate import UnivariateSpline

matplotlib.use('TkAgg')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


# ---------- 设置全局字体 ----------
plt.rcParams.update({
    'font.size': 24,
    'axes.titlesize': 24,
    'axes.labelsize': 24,
    'legend.fontsize': 24,
    'xtick.labelsize': 24,
    'ytick.labelsize': 24
})



# ========================= 参数与数据读取 =========================
def read_csv_file(filename, header=None):
    try:
        return np.array(pd.read_csv(filename, header=header))
    except Exception as e:
        print(f"Error reading {filename}: {e}")
        return None

# # 读取实际轨迹
# excel_file = 'path_in_plan.csv'
# df = pd.read_csv(excel_file)
# x = df['X'].values
# y = df['Y'].values
# points = np.column_stack((x, y))
# _, unique_indices = np.unique(points, axis=0, return_index=True)
# points = points[np.sort(unique_indices)]
# x = points[:, 0]
# y = points[:, 1]

max_curvature_deg1 = 15
# 初始钻头实际点位及入射角
point_in = np.array([560, 3092])
point_in_alpha = 0.2
img_in = "reservoir_image.png"


reservoir_data = read_csv_file("reservoir_data.csv")
path_center_data = read_csv_file("path_center_sweet.csv")

try:
    img_bac = Image.open(img_in).convert('RGB')
    img_bac = np.array(img_bac)
except Exception as e:
    print(f"Error loading reservoir image: {e}")
    img_bac = None

if reservoir_data is not None:
    data_tip_x = reservoir_data[0, 1:]
    data_tip_y = reservoir_data[1:, 0]
    data = reservoir_data[1:, 1:]
    x_lim = [data_tip_x[0], data_tip_x[-1]]
    y_lim = [data_tip_y[0], data_tip_y[-1]]
    n_space_x = data_tip_x[1] - data_tip_x[0]
    n_space_y = data_tip_y[1] - data_tip_y[0]
else:
    exit()

if path_center_data is not None:
    path_x, path_y = path_center_data[1:, 1], path_center_data[1:, 2]
else:
    exit()

spline = UnivariateSpline(path_x, path_y, s=1.0, k=3)
sweet_x = data_tip_x
sweet_y = spline(data_tip_x)
rows_bac, cols_bac, _ = img_bac.shape

# ========================= 曲线函数定义 =========================
def calculate_ticks(lim, size):
    return np.linspace(0, size, 6), np.linspace(lim[0], lim[1], 6, dtype=int)

def find_center_line_point(x):
    y = spline(x)
    dy = spline.derivative()(x)
    return y, dy

def cubic_bezier(t, P0, P1, P2, P3):
    B0 = (1 - t) ** 3
    B1 = 3 * t * (1 - t) ** 2
    B2 = 3 * t ** 2 * (1 - t)
    B3 = t ** 3
    x = B0 * P0[0] + B1 * P1[0] + B2 * P2[0] + B3 * P3[0]
    y = B0 * P0[1] + B1 * P1[1] + B2 * P2[1] + B3 * P3[1]
    return np.array([x, y])

def convert_to_pixel_coords(x, y, x_lim, y_lim, cols_bac, rows_bac):
    x_pic = (x - x_lim[0]) * cols_bac / (x_lim[1] - x_lim[0])
    y_pic = (y - y_lim[0]) * rows_bac / (y_lim[1] - y_lim[0])
    return x_pic, y_pic

def compute_curve_curvature(curve_points):
    dx = np.gradient(curve_points[:, 0])
    dy = np.gradient(curve_points[:, 1])
    ddx = np.gradient(dx)
    ddy = np.gradient(dy)
    numerator = np.abs(dx * ddy - dy * ddx)
    denominator = (dx**2 + dy**2)**1.5 + 1e-8
    curvature = numerator / denominator
    return curvature

# ========================= 自适应设计函数 =========================
def adaptive_design_path(point_in, point_in_alpha, max_curvature_deg=max_curvature_deg1):
    global design_lambda, delta_alpha_design

    # 最大曲率从 1° 开始尝试，单位转换为 rad/m
    for curvature_deg in range(1, max_curvature_deg + 1):
        max_curvature_allowed = curvature_deg * np.pi / 180 / 30

        # 遍历 lambda_val（段长）和 delta_alpha_val（控制点引导长度）
        for lambda_val in range(10, 201):  # 10 ~ 200
            for delta_alpha_val in range(10, 81):  # 10 ~ 70

                # 起点控制点
                point_in_2 = point_in + np.array([
                    np.cos(np.arctan(point_in_alpha)) * delta_alpha_val,
                    np.sin(np.arctan(point_in_alpha)) * delta_alpha_val
                ])

                # 终点目标与控制点
                point_out_x = point_in[0] + lambda_val
                if point_out_x >= x_lim[1]:
                    point_out_x = x_lim[1]

                point_out_y, point_out_alpha = find_center_line_point(point_out_x)
                point_out = np.array([point_out_x, point_out_y])
                point_out_2 = point_out - np.array([
                    np.cos(np.arctan(point_out_alpha)) * delta_alpha_val,
                    np.sin(np.arctan(point_out_alpha)) * delta_alpha_val
                ])

                # 贝塞尔轨迹计算
                t_values = np.linspace(0, 1, 100)
                curve_points = np.array([
                    cubic_bezier(t, point_in, point_in_2, point_out_2, point_out)
                    for t in t_values
                ])

                # 曲率计算
                curvature = compute_curve_curvature(curve_points)

                # 若满足曲率要求，则返回当前轨迹与参数
                if np.all(curvature <= max_curvature_allowed):
                    design_lambda = lambda_val
                    delta_alpha_design = delta_alpha_val
                    return point_out, point_out_alpha, curve_points[:, 0], curve_points[:, 1], lambda_val, delta_alpha_val

    # 如果所有组合都失败，返回 None
    return None, None, None, None, None, None


# ========================= 轨迹生成主流程 =========================


x_point_list, y_point_list = [point_in[0]], [point_in[1]]
path_design_x_list, path_design_y_list = [], []
x_point_pic_list, y_point_pic_list = [], []
origin_pic_list, vector_pic_list = [], []
design_params = []  # ⬅️ 用于保存每段参数

x_pic_in, y_pic_in = convert_to_pixel_coords(point_in[0], point_in[1], x_lim, y_lim, cols_bac, rows_bac)
origin_pic_list.append(np.array([x_pic_in, y_pic_in]))
vector_pic_list.append(np.array([
    np.cos(np.arctan(point_in_alpha)) * 100,
    -np.sin(np.arctan(point_in_alpha)) * 100
]))

for j in range(500):
    result = adaptive_design_path(point_in, point_in_alpha)
    if result[0] is None:
        print(f"\n⚠️ 设计终止：第 {j+1} 段无法满足曲率限制")
        break

    point_out, point_out_alpha, path_design_x, path_design_y, lambda_val, delta_alpha_val = result

    # ========== 计算增强指标 ==========
    curve_array = np.column_stack([path_design_x, path_design_y])
    curvature_vals = compute_curve_curvature(curve_array)
    max_curvature = np.max(curvature_vals)

    dx = np.diff(path_design_x)
    dy = np.diff(path_design_y)
    length = np.sum(np.sqrt(dx**2 + dy**2))

    friction_est = np.sum(curvature_vals) * (length / len(curvature_vals))

    max_curvature_deg_per_30m = max_curvature * 30 * 180 / np.pi
    avg_curvature_deg_per_30m = np.mean(curvature_vals) * 30 * 180 / np.pi
    friction_torque_est_N = friction_est * 1000  # 简化估算，可根据具体模型调整系数

    design_params.append({
        'Segment': j + 1,
        'λ': lambda_val,
        'δd': delta_alpha_val,
        'Max_Curvature (°/30m)': round(max_curvature_deg_per_30m, 2),
        'Average_Curvature (°/30m)': round(avg_curvature_deg_per_30m, 2),
        'Length (m)': round(length, 2),
        'Friction_Torque_Est (N)': round(friction_torque_est_N, 2)
    })

    # ========== ==================== ==========

    point_in = point_out
    point_in_alpha = point_out_alpha

    x_point_list.append(point_in[0])
    y_point_list.append(point_in[1])
    path_design_x_list.extend(path_design_x)
    path_design_y_list.extend(path_design_y)

    x_pic_in, y_pic_in = convert_to_pixel_coords(point_in[0], point_in[1], x_lim, y_lim, cols_bac, rows_bac)
    origin_pic_list.append(np.array([x_pic_in, y_pic_in]))
    vector_pic_list.append(np.array([
        np.cos(np.arctan(point_in_alpha)) * 100,
        -np.sin(np.arctan(point_in_alpha)) * 100
    ]))


# 可视化点转换
for i in range(len(x_point_list)):
    x_pic_point, y_pic_point = convert_to_pixel_coords(x_point_list[i], y_point_list[i], x_lim, y_lim, cols_bac, rows_bac)
    x_point_pic_list.append(x_pic_point)
    y_point_pic_list.append(y_pic_point)

path_x_design_pic, path_y_design_pic = convert_to_pixel_coords(path_design_x_list, path_design_y_list, x_lim, y_lim, cols_bac, rows_bac)
path_x_sweet_pic, path_y_sweet_pic = convert_to_pixel_coords(sweet_x, sweet_y, x_lim, y_lim, cols_bac, rows_bac)
# path_x_in_pic, path_y_in_pic = convert_to_pixel_coords(x, y, x_lim, y_lim, cols_bac, rows_bac)

# ========================= 图像绘制与输出 =========================
def plot_reservoir_path():
    fig, ax = plt.subplots(figsize=(18, 9), dpi=200)
    ax.scatter(x_point_pic_list, y_point_pic_list, color="blue", s=20, zorder=2)
    ax.plot(path_x_sweet_pic, path_y_sweet_pic, linewidth=2, linestyle='-.', color="black", zorder=2)
    # ax.plot(path_x_in_pic, path_y_in_pic, linewidth=4, color="blue", linestyle='-.', label='real path', zorder=2)
    for i in range(len(origin_pic_list)):
        ax.quiver(*origin_pic_list[i], *vector_pic_list[i], width=0.004, color='blue', zorder=2)
    ax.plot(path_x_design_pic, path_y_design_pic, 'blue', linewidth=2, label='design path', zorder=2)
    ax.invert_yaxis()
    plt.imshow(img_bac, zorder=1)
    plt.legend(loc='upper right', fontsize=24)
    plt.xticks(*calculate_ticks(x_lim, cols_bac), size=24, color='black')
    plt.yticks(*calculate_ticks(y_lim, rows_bac), size=24, color='black')
    ax.set_ylabel('Vertical Depth (m)', size=24)
    ax.set_xlabel('Horizontal Length (m)', size=24)
    plt.savefig("设计轨迹.png")

plot_reservoir_path()

# ========================= 数据保存 =========================
df = pd.DataFrame({ 'X': path_design_x_list, 'Y': path_design_y_list })
df.to_excel("设计轨迹_output.xlsx", index=False)

df_params = pd.DataFrame(design_params)
df_params.to_excel("设计参数_output.xlsx", index=False)

print("✅ 设计轨迹计算完成，结果已存为 Excel（设计轨迹_output.xlsx）")
print("✅ 每段轨迹设计参数已保存为 Excel（设计参数_output.xlsx）")
